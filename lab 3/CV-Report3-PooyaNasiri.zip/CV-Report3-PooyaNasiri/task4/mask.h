#include "headers.h"
cv::Mat mask(cv::Mat, cv::Scalar, unsigned int);