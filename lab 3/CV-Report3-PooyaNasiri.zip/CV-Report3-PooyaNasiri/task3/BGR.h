#include "headers.h"
void print_BGR(cv::Mat , int , int);
cv::Scalar mean_BGR(cv::Mat , int , int, int);