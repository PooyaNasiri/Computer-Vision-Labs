#include "headers.h"
cv::Mat mask(cv::Mat, cv::Scalar, unsigned int, cv::Vec<unsigned int, 3>);