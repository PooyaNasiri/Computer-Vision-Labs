#include "headers.h"

cv::Mat min_filter(cv::Mat , int );
cv::Mat max_filter(cv::Mat , int );
cv::Mat gaussian_filter(cv::Mat , int );
cv::Mat median_filter(cv::Mat , int );