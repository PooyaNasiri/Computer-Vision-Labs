#include "headers.h"
cv::Mat DetectYellow(cv::Mat);
cv::Mat DetectCircle(cv::Mat, int);
cv::Mat DrawCircle(cv::Mat, cv::Mat);