#ifndef HEADERS_H
#define HEADERS_H
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#endif // !HEADERS_H